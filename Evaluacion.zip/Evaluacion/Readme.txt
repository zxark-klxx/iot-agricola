Hola profesor
Le adjunto lo siguiente:

===================================================
Los códigos Python se encuentran en: "Backend_agro"
===================================================

Links:

===================================================
GitHub (Proyecto Android Studio): https://github.com/zxark-klxx/iot-agricola
Google Drive (Video): https://drive.google.com/file/d/1KZPCzxjtp_3Mhg8GAHEpq4t35MjaksBb/view?usp=sharing
===================================================
